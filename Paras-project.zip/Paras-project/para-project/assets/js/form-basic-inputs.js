'use strict';

(function () {

  const checkbox = document.getElementById('defaultCheck2');
  checkbox.indeterminate = true;
})();
